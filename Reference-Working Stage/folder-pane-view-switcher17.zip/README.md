Folder Pane View Switcher Thunderbird add-on
============================================

AMO home page, from which the add-on can be downloaded and installed:
[https://addons.mozilla.org/thunderbird/addon/folder-pane-view-switcher/](
https://addons.mozilla.org/thunderbird/addon/folder-pane-view-switcher/)

Author: Jonathan Kamens <[jik+fpvs@kamens.us](
mailto:jik+fpvs@kamens.us)>

Copyright (c) 2011,2012,2015 Jonathan Kamens.

Released under the terms of the Mozilla Public License, v. 2.0. The
MPL can be found in the file [LICENSE](LICENSE).
