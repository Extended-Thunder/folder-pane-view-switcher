pref("extensions.FolderPaneSwitcher.logging.console","Warn");
pref("extensions.FolderPaneSwitcher.logging.dump","Warn");
pref("extensions.FolderPaneSwitcher.arrows",true);
pref("extensions.FolderPaneSwitcher.delay",1000);
pref("extensions.FolderPaneSwitcher.dropDelay",1000);
// https://developer.mozilla.org/en/Localizing_extension_descriptions
pref("extensions.FolderPaneSwitcher@kamens.us.description", "chrome://FolderPaneSwitcher/locale/overlay.properties");
